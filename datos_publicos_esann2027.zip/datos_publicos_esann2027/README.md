# Datos y esquemas públicos (ESANN 2027) — mama `pub1`, mama `pub2` y riñón `rin1`

Versión del 25-11-2026. Todo el texto
viene de corpus públicos; las etiquetas son **débiles** (consenso de varios LLM). Licencia de los datos: `LICENSE-DATA`
(CC BY-NC-SA 4.0). Cifras exactas en `estadisticas.json`; sumas md5 de todo en `MD5SUMS.txt`.

## Estructura

```
esquemas/
  mama/   tree_mama.json (245 nodos; md5 b3fb732a…)   tree_mama_council.json (mismo árbol + definiciones y opciones)
  rinon/  tree_rinon.json (113 nodos)                  tree_rinon_council.json
corpus/
  mama_pub1/   notas/  splits/  espacio/  procedencia/
  mama_pub2/   notas/  splits/  espacio/  procedencia/
  rinon_rin1/  notas/  splits/  espacio/  procedencia/
estadisticas.json   MD5SUMS.txt   LICENSE-DATA
```

- `notas/<origen>_<id>-<k>.json`: una nota por archivo, sólo las que usan los splits. `k = 0` es el informe original;
  `k = 1…5` son paráfrasis generadas con LLM (sólo en train; heredan el split de su original).
  Campos: `note_text`; `labels` (`start`, `end` en caracteres, `variable_id`, `variable_name`, `votos`, `modelos`);
  `source_file`; `cancer`; `origen`; `meta_origen` (TCGA: paciente y tipo); `consenso` (regla, votos necesarios,
  modelos que votaron y consultados).
- `splits/{train,validation,test}.json`: listas de rutas **relativas** a la carpeta del corpus (`notas/<…>.json`).
  Los tres splits de cada corpus son disjuntos (verificado).
- `espacio/`: el espacio de retroceso del corpus, ajustado con su train: árbol (`tree_dict_hier_*`, `tree_dict_*` = campos
  etiquetables), tipos de arista (`edge_types_*`), cadenas admisibles (`fallback_tree_*`), `espacio.json` (campos excluidos).
  El árbol de cada corpus es idéntico al de `esquemas/` (verificado por md5).
- `procedencia/`: la partición por sitio (`splits_por_sitio/`, rutas relativas como en `splits/`), los `MD5SUMS` de cuando
  se armó cada corpus, la configuración de sitios, los resúmenes del consenso y el esquema con que se armó. Sólo para trazabilidad;
  las rutas de máquina se quitaron, por eso algunos `MANIFIESTO`, `edge_stats` y logs ya no coinciden con esos `MD5SUMS`.

## Fuentes y partición (las tres versiones)

Textos públicos en español: casos clínicos e informes de **CANTEMIST** (`cantemist`), **CodiEsp** (`codiesp`), el **Chilean
Waiting List corpus** (`cwlc`), el corpus de topografía y morfología de **FALP** publicado en Zenodo (`falp`,
doi:10.5281/zenodo.5555431), `bg`, e informes de **TCGA** traducidos al español (`tcga`). Se agrupan en tres sitios:
`centro` = cantemist + codiesp, `otros` = falp + bg + cwlc, `tcga`; cada sitio se parte 60/20/20 (semilla 0) y las
paráfrasis van sólo a train. Etiquetas: el council de LLM etiqueta cada nota contra el esquema y una etiqueta (campo +
span) se conserva si la dan al menos la mitad de los modelos que votaron esa nota (1 de 2, 2 de 3; spans solapados de la
misma clase se funden en el más corto).

Campos excluidos de las referencias (presentes en las notas, fuera del conteo y de la evaluación):
mama 1201 Hallazgos adicionales, 1202 Comentarios, 1301 Comportamiento, 1401 Extensión diagnóstico;
riñón 801 Hallazgos adicionales, 901 Comentarios, 1001 Comportamiento, 1101 Extensión diagnóstico.

## mama `pub1` — el corpus de la Tabla 1 del paper

| split | notas | originales | TCGA | menciones | etiquetas | menciones con ≥ 2 etiquetas |
|---|---|---|---|---|---|---|
| train | 1.284 | 678 | 403 | 23.122 | 29.540 | 5.066 |
| validation | 226 | 226 | 134 | 4.892 | 6.191 | 1.053 |
| test | 224 | 224 | 134 | 4.561 | 5.775 | 966 |

Votantes: textos abiertos con **gpt-oss-120b + Qwen3.6-27B** (basta 1 de 2: unión; 86 notas sólo con Qwen, donde gpt-oss
se abstuvo); TCGA con **gpt-oss-120b** (1 votante; versión con informes truncados). Test por origen: 134 tcga, 37 cantemist,
34 falp, 10 bg, 7 cwlc, 2 codiesp.

## mama `pub2` — réplica con más datos y un tercer etiquetador (no está en el paper)

| split | notas | originales | TCGA | menciones | etiquetas | menciones con ≥ 2 etiquetas |
|---|---|---|---|---|---|---|
| train | 3.869 | 896 | 2.355 | 98.143 | 124.360 | 20.251 |
| validation | 299 | 299 | 207 | 9.810 | 12.801 | 2.208 |
| test | 296 | 296 | 206 | 9.662 | 12.789 | 2.289 |

Mismo esquema y misma regla. Cambios respecto de `pub1`: textos abiertos con **gpt-oss + Qwen3.6 + DeepSeek** (2 de 3);
TCGA con **gpt-oss v2 (sin truncados) + DeepSeek** (unión); más paráfrasis (p1–p5 y relleno; las de TCGA y parte de las
abiertas, etiquetadas sólo por gpt-oss) y más TCGA. El espacio de retroceso se reajustó con este train.
**Las particiones de `pub1` y `pub2` NO son compatibles:** comparten 120 notas de test, pero 73 notas del test de `pub1`
están en el train de `pub2` y 85 notas del train de `pub1` están en el test de `pub2`. Nunca evaluar un modelo de una
versión en el test de la otra.

## riñón `rin1`

| split | notas | originales | TCGA | menciones | etiquetas | menciones con ≥ 2 etiquetas |
|---|---|---|---|---|---|---|
| train | 3.027 | 701 | 2.143 | 45.986 | 50.764 | 4.633 |
| validation | 234 | 234 | 183 | 4.365 | 4.843 | 456 |
| test | 232 | 232 | 183 | 4.158 | 4.619 | 446 |

Esquema de 113 nodos (95 campos etiquetables). Votantes: textos abiertos con **gpt-oss + Qwen3.6 + DeepSeek** (2 de 3);
TCGA con **gpt-oss v2 + DeepSeek** (unión). Test por origen: 183 tcga, 18 cantemist, 17 falp, 9 bg, 3 codiesp, 2 cwlc.

## Calidad de las referencias (validación ciega; ver el paper)

| | precisión de las referencias (borde = correcto) | exhaustividad estimada |
|---|---|---|
| mama `pub1` (humana, 150 + 75 etiquetas) | 88,7 % | ~70 % |
| riñón `rin1` (humana) | 98,6 % (139 decididas) | ~89 % |
| mama `pub2` (juez LLM Opus, 54 notas de test) | 91,3 % | ~76 % |

## Integridad

`MD5SUMS.txt` lista la suma md5 de cada archivo de esta carpeta (`md5sum -c MD5SUMS.txt`). Las notas, los splits y los
archivos de datos del espacio se cotejaron uno por uno con las copias de trabajo usadas en el paper.

## Fuentes y licencias

Las etiquetas, los esquemas y los espacios se distribuyen bajo CC BY-NC-SA 4.0 (`LICENSE-DATA`). Los textos siguen bajo
la licencia de su fuente original; quien los use debe citar y respetar cada una (CANTEMIST, CodiEsp, Chilean Waiting
List corpus, el corpus de Villena et al. en Zenodo y TCGA-Reports).
